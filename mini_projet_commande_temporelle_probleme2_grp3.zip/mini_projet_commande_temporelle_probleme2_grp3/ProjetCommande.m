clear all
close all
clc
Ts = 0.00001;
% syms R7 R9 R10 R11 C4 C5 C3 R8 R13
% L1 = [R11*C4 R11*C5+R10*C5;0 R10*C5]
% L2 = [0 -1;1 R7/R9]
% L3 = [1;0]
% IL1 = inv(L1)
% A1 = IL1*L2
% B1 = IL1*L3
R7 = 5000;
R8 = 2000;
R9 = 5000;
R10 = 11000;
R11 = 5000;
R13 = 4000;
C3 = 330e-9;
C4 = 470e-9;
C5 = 470e-9;
% R10 = 13000;
% R13 = 4700;
A = [(-(R10+R11))/(C4*R10*R11) -((1/(C4*R11))+((R7*(R10+R11))/(C4*R9*R10*R11))) 1/(C4*R11);1/(C5*R10) R7/(C5*R9*R10) 0;0 0 ((-1/C3)*((R8+R13)/(R8*R13)))];
B = [0;0;1/(R8*C3)];
C = [0 1+(R7/R9) 0];
D = [0];
Mc = ctrb(A,B)
r = rank(Mc)
Mo = obsv(A,C)
r1 = rank(Mo)
sys=ss(A,B,C,D)

%% Question 2 - Simulation en BO
figure()
step(sys,0.5),grid
title('Simulation du system en BO')

%% Question 3 - Commande de Y1
Ap = [0 0 1 0;zeros(3,1) A];
Bp = [0;B];
Kc=place(Ap,Bp,[-100 -150 -200 -300]);

%% Question 4 - Observateur
Ko=place(A',C',[-1000 -2000 -3000])';
sim('ProjetCommande_SIM')
figure()
plot(t,Y1),grid
legend('Y1')
title('Sortie controlee')

figure()
plot(t,Xest),grid
title('Les etats observes')
legend('Uc4','Uc5','Y2')

%% Question 5 - Simulation numerique
tsim = 1;  %s
N = round(tsim/Ts);
x = zeros(3,N);
u = zeros(1,N);
y = zeros(1,N);
t = zeros(1,N);
xest =  zeros(3,N);
yest =  zeros(1,N);
Ad = eye(3,3) + Ts*A;
Bd = Ts*B;
yref = [2];
Iy = [0];
% Simulation
for i=1:N-1 
   % Control 
   % u = -Kc*V
   Ey = y(:,i) - yref;
   Iy = Iy +Ts*Ey ;
   Vt = [Iy;xest(:,i)]; %%  
   u(:,i) = -Kc*Vt;
   
   
   % Observateur 
   espy = y(:,i)-yest(:,i);
   xest(:,i+1) = xest(:,i) + Ts*(A*xest(:,i)+B*u(:,i)+Ko*espy);
   yest(:,i+1) = C*xest(:,i)+D*u(:,i);
  
   x(:,i+1) = Ad*x(:,i) + Bd*u(:,i);
   y(:,i+1) = C*x(:,i+1) + D*u(:,i);
   
   t(i+1) = t(i) + Ts;
end

figure()
plot(t,xest(1,:)),grid
hold on
plot(t,xest(2,:))
plot(t,xest(3,:))
legend('Uc4_e_s_t','Uc5_e_s_t','Y2_e_s_t')

figure()
plot(t,y(1,:)),grid
legend('Y1')

figure()
plot(t,u(1,:)),grid
legend('U1')