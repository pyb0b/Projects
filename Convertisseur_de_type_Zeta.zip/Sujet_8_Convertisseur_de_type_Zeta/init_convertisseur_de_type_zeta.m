clear all;
close all;
clc;

f =50e+3; %Hz
E1 = 62; %V %tension d'entree
P0 = 250; %W puissance consomme par lle convertisseur
E0 = 48; %V %tension de sortie
I0 = P0/E0; %A courant de sortie
R0 = E0/I0; %Ohm 

Ts = 1/f; %s
k = 4/9; 
K = 100*k; % pulse width en %

I1 = I0*k/(1-k); %courant de sortie

L2 = (E1*k)/(0.01*f*I0) ; %H
L1 = (E1*k)/(0.01*f*I1) ; %H 

C =  k/(R0*0.01*f); %F
C0 = k/(R0*0.01*f) ; %F 

sim("convertisseur_de_type_zeta")

figure()
subplot(1,2,1)
plot(t(size(t)-350:size(t)),iL1(size(t)-350:size(t))),grid
legend("iL1")
xlabel("t")

subplot(1,2,2)
plot(t(size(t)-350:size(t)),iL2(size(t)-350:size(t))),grid
legend("iL2")
xlabel("t")

figure()
subplot(1,2,1)
plot(t(size(t)-350:size(t)),iC(size(t)-350:size(t))),grid
legend("iC")

subplot(1,2,2)
plot(t(size(t)-350:size(t)),iC0(size(t)-350:size(t))),grid
legend("iC0")
xlabel("t")

figure()
subplot(1,2,1)
plot(t(size(t)-350:size(t)),iQ(size(t)-350:size(t))),grid
legend("iQ")
xlabel("t")

subplot(1,2,2)
plot(t(size(t)-350:size(t)),iD(size(t)-350:size(t))),grid
legend("iD")
xlabel("t")

figure()
subplot(1,2,1)
plot(t(size(t)-350:size(t)),vQ(size(t)-350:size(t))),grid
legend("vQ")
xlabel("t")

subplot(1,2,2)
plot(t(size(t)-350:size(t)),E(size(t)-350:size(t))),grid
legend("E")
xlabel("t")

figure()
plot(t(size(t)-350:size(t)),vD(size(t)-350:size(t))),grid
legend("vD")
xlabel("t")

figure()
subplot(1,2,1)
plot(t(size(t)-350:size(t)),vL1(size(t)-350:size(t))),grid
legend("vL1")
xlabel("t")

subplot(1,2,2)
plot(t(size(t)-350:size(t)),vL2(size(t)-350:size(t))),grid
legend("vL2")
xlabel("t")

figure()
plot(t,vC),grid
legend("vC")
xlabel("t")

figure()
subplot(1,2,1)
plot(t,v0),grid
legend("v0")
xlabel("t")

subplot(1,2,2)
plot(t,i0),grid
legend("i0")
xlabel("t")
