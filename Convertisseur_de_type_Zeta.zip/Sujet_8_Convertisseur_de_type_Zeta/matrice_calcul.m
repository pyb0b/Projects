clear all;
close all;
clc;

syms D L1 L2 C0 C R0 V0 E p IL1 IL2

A = [0 0 0 (D-1)/L1;0 0 0 (D-1)/L2;(D-1)/C D/C 0 0;0 1/C0 0 -1/(R0*C0)];
B = [(V0+E)/L1;(V0+E)/L2;(IL1+IL2)/C;0];
pI4 = [p 0 0 0;0 p 0 0;0 0 p 0;0 0 0 p];

G = inv(pI4 - A)*B

% les termes avec D sont elimines
% les termes de forme (1-D)*terme = terme 