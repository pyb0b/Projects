clear all;
close all;
clc;

%% initialisation
Un = 400  ;% V
Fn = 50  ;% Hz
Nb = 3000  ;% tr/min
Pn = 22000  ;% 22 kW
Mn = 71.5  ;% N.m
Nn = 2938  ;% tr/min
In = 37.6  ;% A
Id_sur_In = 7.7;
Md_sur_Mn = 2.4;
Mm_sur_Mn = 2.9;
J = 0.0812;
masse = 168  ;% Kg
cos_phi_n = 0.92;
eta_n = 0.914  ;% 91.4%

%% determination des element de la MAS a cage
Vn = Un/sqrt(3)  ;% V
OMEGA_N = 2*pi*Nn/60  ;% rd/s
Sn = Pn/(eta_n*cos_phi_n)  ;%VA
P = 1  ;%pole = 1 car Fn = 50 Hz et Nb = 3000 tr/min 
gn = (Nb - Nn)/Nb  ;%tr/min
w_n = 2*pi*Fn  ;%Hz
Mm = Mn * Mm_sur_Mn  ;%N.m
Md = Mn * Md_sur_Mn  ;%N.m
Id = In * Id_sur_In  ;%A
Zn = Vn/In  ;%Ohm 
% Mm = (3pVn^2)/(w_n * 2N'2w)
N2_prime_w = (3*P*Vn^2)/(2*w_n*Mm)  %Ohm
%Mn = (3pVn^2)*(R'2/gn)/(w_n*((R'2/gn)^2 + N'2w^2))
%Mn*(R'2/gn)^2 - (3pVn^2)*(R'2/gn)/w_n + Mn*(N'2w)^2 = 0
a = Mn/gn^2;
b = (-3*P*Vn^2)/(w_n*gn);
c = Mn*(N2_prime_w)^2;
delta = b^2 - 4*a*c;
x1 = (-b - sqrt(delta))/(2*a);  %Ohm
x2 =(-b + sqrt(delta))/(2*a);

gM1 = x1/N2_prime_w
gM2 = x2/N2_prime_w %il faut que gM > gn (cours machine 1) 
% apres le run, gn > gM1 donc on prend gM2

R2_prime = x2

r2_prime = R2_prime/Zn  %p.u.
n2_prime_w = N2_prime_w/Zn  %p.u.
Y1n = (In/Vn)*exp(-1j*acos(cos_phi_n))  ;
Yn = Y1n - (1/((R2_prime/gn) + 1j*N2_prime_w))  ;
Rpfe = 1/real(Yn)  %Ohm
L1_w = -1/imag(Yn)  %Ohm
rpfe = Rpfe/Zn
l1_w = L1_w/Zn
%% determination de R1 et fv
R1 = R2_prime  %Ohm (propose par l'enseignant dans les seances)
r1 = r2_prime
Pfe = (Vn^2)/Rpfe  ;%Pertes fer
Pjoule = R1*In^2  ;%Perte joules
beta = Pfe/Pn  ;
gamma = Pjoule/Pn  ;
alpha = 1 - eta_n - beta - gamma  ;% en %
Pmn = alpha*Pn  ;%Watt
fv = Pmn/OMEGA_N^2  %coefficient des frottements visqueuses en N.m.s/rad

%% determination de Ls/Lr/Msr/sigma
N2_prime = N2_prime_w/w_n  ;
L1 = L1_w/w_n  ;
Ls = (N2_prime/2) + L1
Lr = Ls  %comme le rotor est refere au stator
Msr = L1
sigma = 1 - (Msr^2/(Ls*Lr)) 
%% quelque initialisation
matrice_Concordia = sqrt(2/3)*[1 -0.5 -0.5;
                       0 sqrt(3)/2 -sqrt(3)/2;
                       1/sqrt(2) 1/sqrt(2) 1/sqrt(2)];
Amplitude = Un*sqrt(2)/sqrt(3);
Rs = R1; % la notation Rs et Rr est plus simple
Rr = R2_prime; 
phi = pi/3 ;
matrice_flux_intensite=inv([Ls 0 Msr 0; 0 Ls 0 Msr; Msr 0 Lr 0; 0 Msr 0 Lr]);
inv_matrice_Concordia = inv(matrice_Concordia);

%% choix de couple
disp("Dans ce programme, on peut considerer plusieur choix pour le couple de charge:")
disp("choix 1: Couple constant")
disp("choix 2: Couple proportionnel")
disp("choix 3: Couple parabole")

choix = 0; %pour le choix
cas = 0; %pour la switch 1 en simulink
cas_pr = 0; %pour la switch 2 en simlink
parametre = 1; %parametre de la boucle while qu'on va faire
val_choix_constant = 0;
val_choix_proportionnel = 0;
val_choix_parabole = 0;
Kc = Mn/OMEGA_N;
Kc_pr = Mn/OMEGA_N^2;

while parametre == 1
    choix = input("inserer le choix que vous desirez:")
    if choix == 1
        val_choix_constant = input("inserer le couple de charge qui doit etre inferieur a Cn = 71.5 N.m:")
        if val_choix_constant<=0 || val_choix_constant>=Mn
            disp("choix incorrect, veuillez resaisir")
        else
            disp("choix correct")
            cas = 1;
            cas_pr = 0;
            parametre = 0;
        end
        
    elseif choix == 2
        val_choix_proportionnel = input("inserer le coefficient k qui doit etre inferieur a Kc = Cn/OMEGA_n = 0.2324:")
        if val_choix_proportionnel<=0 || val_choix_proportionnel>=Kc
            disp("choix incorrect, veuillez resaisir")
        else
            disp("choix correct")
            cas = 0;
            cas_pr = 1;
            parametre = 0;
        end
            
    elseif choix == 3
        val_choix_parabole = input("inserer le coefficient k qui doit etre inferieur a Kc_pr = Cn/OMEGA_n^2 = 7.5534e-4:")
        if val_choix_parabole<=0 || val_choix_parabole>=Kc_pr
            disp("choix incorrect, veuillez resaisir")
        else
            disp("choix correct")
            cas = 0;
            cas_pr = 0;
            parametre = 0;
        end
    else
        disp("choix incorrect, veuillez resaisir")
    end
end
%% choix de resistance rotorique
R0 = Rr;
Tf = 0;
T0 = 0;
alpha_temperature = 4e-3;
choix_resistance = 0;
parametre = 1;

disp("on donne le choix a l'utilisateur de choisir soit une resistance constante soit variable:")
disp("choix 1: constante")
disp("choix 2: variable")

while parametre == 1
    choix_resistance = input("inserer le choix que vous desirez:")
    if choix_resistance == 1
        choix_resistance = 1;
        parametre = 0;
    elseif choix_resistance == 2
        choix_resistance = 0;
        T0 = input("inserer la temperature initial: ")
        Tf = input("inserer la temperature final: ")
        if T0<Tf
            parametre = 0;
        else 
            disp("choix incorrecte, resaisir")
        end
    else
        disp("choix incorrecte, resaisir")
    end
end

%% R�gulation du flux
Tr = Lr/R2_prime;
Ts = Ls/Rs;
Imrn = Un/(2*pi*Fn*Msr);
Cemn = Mn+Pmn/OMEGA_N; 
tau = 1;
phi_rd_n = Un/(2*pi*Fn);
kond = 1;
p = tf('p');

Hphi_BO = (1/Rs)/(1+(Ts+Tr)*p +Tr*Ts*sigma*p^2); 
syms z
poles_flux = pole(Hphi_BO);   

w1 = min(abs(poles_flux));
w2 = max(abs(poles_flux));
T = 1/0.8603;
TfBF = Tr/5;       

K_gain_flux = 2.4;
Toi_flux = 1/w1;


%% R�gulation du couple
phi_rd = Un/(2*pi*sqrt(2)*Fn);
Imr_ref = phi_rd/Msr;
parametre=P*Msr^2*Imr_ref/(Rs*Lr);
HC_BO = parametre/((1+sigma*Ls*p/Rs)*(1+TfBF*p));
poles_couple = pole(HC_BO);

TcBF = sigma*Ts/5;
T1=1/8.5026;

K_gain_couple = 3;
Toi_couple = TfBF;


%% R�gulation de la vitesse
Hv_BO = 1/((J*p+fv)*(1+TcBF*p));
poles_vitesse =double(solve((J*z+fv)*(1+TcBF*z)));  

K_gain_vitesse = 10;  %pour le regulateur seul 0.46
Toi_vitesse = J/fv;
K_gain_vitesse_regulateur_seul = 0.46 ; %seul ce gain est different que 
                                  %celui qu'on a implemente dans le MAS
%% courbes des regulation seul

sim("TC_MAS_regulateurs_seul.slx")

figure()
plot(t,flux_reg_seul_ref,'r'),grid
hold on
plot(t,flux_reg_seul_sortie,'b')
xlabel("temps (en s)")
ylabel("flux")
legend("reference","sortie")
title("regulation de flux")

figure()
plot(t,couple_reg_seul_ref,'r'),grid
hold on
plot(t,couple_reg_seul_sortie,'b')
xlabel("temps (en s)")
ylabel("couple (en N.m)")
legend("reference","sortie")
title("regulation de couple")

figure()
plot(t,vitesse_reg_seul_ref,'r'),grid
hold on
plot(t,vitesse_reg_seul_sortie,'b')
xlabel("temps (en s)")
ylabel("vitesse (en rd/s)")
legend("reference","sortie")
title("regulation de vitesse")

%% Courbes dans le Simulink complet (dont on implemente la MAS)

sim("TC_MAS.slx")

figure()
plot(t,vitesse_ref,'r'),grid
hold on
plot(t,vitesse_sortie,'b')
xlabel("temps (en s)")
ylabel("vitesse (en rd/s)")
legend("reference","sortie")
title("vitesse en fct de temps dans la MAS")

figure()
plot(t,Cem_ref,'r'),grid
hold on
plot(t,Cem_sortie,'b')
xlabel("temps (en s)")
ylabel("Cem (en N.m)")
legend("reference","sortie")
title("Couple emmagazine en fonction de temps")

figure()
plot(t,imr_ref,'r'),grid
hold on
plot(t,imr_sortie,'b')
xlabel("temps (en s)")
ylabel("imr (en A)")
legend("reference","sortie")
title("imr en fonction de temps")

figure()
plot(t,i_s_d,'r'),grid
hold on
plot(t,i_s_q,'b')
xlabel("temps (en s)")
ylabel("courant (en A)")
legend("i_sd","i_sq")
title("courant statorique en fonction de temps")

figure()
plot(t,i_r_d,'r'),grid
hold on
plot(t,i_r_q,'b')
xlabel("temps (en s)")
ylabel("courant (en A)")
legend("i_rd","i_rq")
title("courant rotorique en fonction de temps")

figure()
plot(t,v_s_d,'r'),grid
hold on
plot(t,v_s_q,'b')
xlabel("temps (en s)")
ylabel("tension (en V)")
legend("v_sd","v_sq")
title("tension statorique en fonction de temps")

figure()
plot(t,Rho,'b'),grid
xlabel("temps (en s)")
ylabel("Rho (en rd)")
legend("Rho")
title("angle Rho en fonction de temps")
                                       