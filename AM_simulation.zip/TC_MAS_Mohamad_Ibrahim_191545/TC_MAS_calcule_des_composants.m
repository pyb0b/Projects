clear all;
close all;
clc;

%% initialisation
Un = 400  ;% V
Fn = 50  ;% Hz
Nb = 3000  ;% tr/min
Pn = 110000  ;% 110 kW
Mn = 354  ;% N.m
Nn = 2970  ;% tr/min
In = 186  ;% A
Id_sur_In = 6.3;
Md_sur_Mn = 1.8;
Mm_sur_Mn = 2.5;
J = 1.3;
masse = 980  ;% Kg
cos_phi_n = 0.9;
eta_n = 0.951  ;% 95.1%

%% determination des element de la MAS a cage
Vn = Un/sqrt(3)  ;% V
OMEGA_N = 2*pi*Nn/60  ;% rd/s
Sn = Pn/(eta_n*cos_phi_n)  ;%VA
P = 1  ;%pole = 1 car Fn = 50 Hz et Nb = 3000 tr/min 
gn = (Nb - Nn)/Nb  ;%tr/min
w_n = 2*pi*Fn  ;%Hz
Mm = Mn * Mm_sur_Mn  ;%N.m
Md = Mn * Md_sur_Mn  ;%N.m
Id = In * Id_sur_In  ;%A
Zn = Vn/In  ;%Ohm 
% Mm = (3pVn^2)/(w_n * 2N'2w)
N2_prime_w = (3*P*Vn^2)/(2*w_n*Mm)  %Ohm
%Mn = (3pVn^2)*(R'2/gn)/(w_n*((R'2/gn)^2 + N'2w^2))
%Mn*(R'2/gn)^2 - (3pVn^2)*(R'2/gn)/w_n + Mn*(N'2w)^2 = 0
a = Mn/gn^2;
b = (-3*P*Vn^2)/(w_n*gn);
c = Mn*(N2_prime_w)^2;
delta = b^2 - 4*a*c;
x1 = (-b - sqrt(delta))/(2*a);  %Ohm
x2 =(-b + sqrt(delta))/(2*a);

gM1 = x1/N2_prime_w
gM2 = x2/N2_prime_w %il faut que gM > gn (cours machine 1) 
% apres le run, gn > gM1 donc on prend gM2

R2_prime = x2

r2_prime = R2_prime/Zn  %p.u.
n2_prime_w = N2_prime_w/Zn  %p.u.
Y1n = (In/Vn)*exp(-1j*acos(cos_phi_n))  ;
Yn = Y1n - (1/((R2_prime/gn) + 1j*N2_prime_w))  ;
Rpfe = 1/real(Yn)  %Ohm
L1_w = -1/imag(Yn)  %Ohm
rpfe = Rpfe/Zn
l1_w = L1_w/Zn
%% determination de R1 et fv
R1 = R2_prime  %Ohm (propose par l'enseignant dans les seances)
r1 = r2_prime
Pfe = (Vn^2)/Rpfe  ;%Pertes fer
Pjoule = R1*In^2  ;%Perte joules
beta = Pfe/Pn  ;
gamma = Pjoule/Pn  ;
alpha = 1 - eta_n - beta - gamma  ;% en %
Pmn = alpha*Pn  ;%Watt
fv = Pmn/OMEGA_N^2  %coefficient des frottements visqueuses en N.m.s/rad

%% determination de Ls/Lr/Msr/sigma
N2_prime = N2_prime_w/w_n  ;
L1 = L1_w/w_n  ;
Ls = (N2_prime/2) + L1
Lr = Ls  %comme le rotor est refere au stator
Msr = L1
sigma = 1 - (Msr^2/(Ls*Lr)) 

%% changement de R'2 (resistance rotorique)
disp("la valeur de la resistance rotorique est 0.0137 Ohm")
change = input("inserer 1 si vous voulez changer cette valeur (sinon inserer un autre nombre):")
if change == 1
    T = input("inserer la temperature en degre C (entre 0 et 100):")
    Tref = input("inserer la temperature reference (generalement 0):")
    A = 3.91*10^(-3);
    B = -0.588 * 10^(-6);
    R0 = R2_prime;
    if T>100
        R0 = 1000*R2_prime;
    end
    disp("nouvelle valeur de R rotorique")
    R2_prime = R0*(1+A*(T-Tref)+B*(T-Tref)^2);   
end
%% quelque initialisation
matrice_Concordia = sqrt(2/3)*[1 -0.5 -0.5;
                       0 sqrt(3)/2 -sqrt(3)/2;
                       1/sqrt(2) 1/sqrt(2) 1/sqrt(2)];
Amplitude = Un*sqrt(2)/sqrt(3);
Rs = R1; % la notation Rs et Rr est plus simple
Rr = R2_prime; 
phi = pi/3 ;
matrice_flux_intensite=inv([Ls 0 Msr 0; 0 Ls 0 Msr; Msr 0 Lr 0; 0 Msr 0 Lr]);
inv_matrice_Concordia = inv(matrice_Concordia);

%% ce code suivant pour calculer Mr (couple resistif)
kc = 0;
k = Mn/OMEGA_N;
Mr = 0;
parametre = 1;
disp("cas 0: Mr (couple resistif) et une cte")
disp("cas non 0: Mr est lineaire")
cas = input("veuillez entrer le cas desire:")


while parametre == 1
    if cas == 0
        Mr = input("veuillez entrer le Mr (doit etre <Mn=354 N.m):")
        if Mr <= Mn && Mr >= 0
            disp("valeur valable de Mr")
            parametre = 0;
        else
            disp("valeur non- valable de Mr")
        end
    else
        disp("on a Mr = kc*OMEGA et kc < Mn/OMEGA_N")
        kc =  input("veuillez entrer kc (doit etre <1.13 N.m.s/rd):")
        if kc <= k && kc >= 0
            disp("valeur valable de kc")
            parametre = 0;
        else
            disp("valeur non- valable de kc")
        end
    end
end


%% les graphes
sim("TC_MAS.slx");

figure()
plot(t,va,"r")
grid on
hold on
plot(t,vb,"b")
plot(t,vc,"g")
legend("va","vb","vc")
ylabel("tensions d'entree (phases)")
xlabel("temps")

figure()
plot(t,v_s_alpha,"r")
grid on
hold on
plot(t,v_s_beta,"b")
legend("v s alpha","v s beta")
ylabel("tensions statoriques")
xlabel("temps")

figure()
plot(t,phi_s_alpha,"r")
grid on
hold on
plot(t,phi_s_beta,"b")
plot(t,phi_r_alpha,"g")
plot(t,phi_r_beta,"m")
legend("phi s alpha","phi s beta","phi r alpha","phi r beta")
ylabel("flux statoriques et rotoriques")
xlabel("temps")

figure()
plot(t,OMEGA,"k")
grid on
legend("OMEGA")
ylabel("vitesse mecanique du rotor")
xlabel("temps")

figure()
plot(t,i_s_alpha,"r")
grid on
hold on
plot(t,i_s_beta,"b")
plot(t,i_r_alpha,"g")
plot(t,i_r_beta,"m")
legend("i s alpha","i s beta","i r alpha","i r beta")
ylabel("intensites statoriques et rotoriques")
xlabel("temps")

figure()
plot(t,i_s_a,"r")
grid on
hold on
plot(t,i_s_b,"b")
plot(t,i_s_c,"g")
legend("i s_a","i s_b","i s_c")
ylabel("intensites de sortie statoriques (phases)")
xlabel("temps")

figure()
plot(t,i_r_a,"r")
grid on
hold on
plot(t,i_r_b,"g")
plot(t,i_r_c,"b")
legend("i r_a","i r_b","i r_c")
ylabel("intensites de sortie rotorique (phases)")
xlabel("temps")

figure()
plot(t,Cr,"k")
grid on
legend("Cr")
ylabel("couple resistant")
xlabel("temps")
