clear all
close all
clc

Tf = 0.1;
Tsim = 1e-5;

% Signal de R�f�rence
fref = 50;
Tref = 1/fref;
m = 54;

% Signal triangulaire
r = 0.85;
Vtri = 1;
fs = m*fref;
Ts = 1/fs;

% Charge lin�aire
R = 12;
L = 25e-3;
Uc1eff = 220;
E = (sqrt(2)*Uc1eff)/r;

sim('TC_Sujet5sim')

figure()
plot(t,Tri),grid
hold on
plot(t,Uc)
plot(t,Moins_Uc)
legend("v_t_r_i","u'c","-u'c")
title('Signal modulant et signal de modulation')

figure()
plot(t,SQ1),grid
legend('SQ1')
title('Signal de Commutation SQ1')

figure()
plot(t,SQ3),grid
legend('SQ3')
title('Signal de Commutation SQ3')

figure()
plot(t,Isource),grid
legend('i_s')
title("Courant de Source")

figure()
plot(t,Ucharge),grid
legend('u_c')
title("Tension de Sortie de l'Onduleur")

figure()
plot(t,Icharge),grid
legend('i_c')
title("Courant de la Charge RL")