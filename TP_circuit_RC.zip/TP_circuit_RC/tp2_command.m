clear all;
close all;
clc;

R = 10.9e+3;
C = 2.2e-6;
tau = R*C;
Ts = 0.001;

Hp = tf(1,[tau 1]);
Hz = c2d(Hp,Ts,'zoh');

c = 0.9592;
p1z = exp(-Ts/(2*tau));
k = (1 - p1z)/0.04084 ;

Cz = tf([k -k*c],[1 -1],Ts);
Hbo = Cz *Hz;

figure()
Hbf = feedback(Hbo,1);
step(Hbf),grid

