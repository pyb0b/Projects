clear all
close all
clc

%% initialisation
Pn = 78e+3; %W
Un = 400; %V
In = 195; %A
etha = 0.91; %p.u.
Cn = 303; %N.m
Nn = 2240; %tr/min
L = 2.4e-3; %H
R115 = 0.14; %Ohm
J = 0.45; %kg.m^2
Pf_sur_Pm = 2/3;

%% calcule des parametre
Pj = R115*In^2; %W
gamma = Pj/Pn;
alpha = (3/5)*(1-etha-gamma) ;
beta = Pf_sur_Pm*alpha;
Pm = alpha*Pn; %W
Pf = beta*Pn; %W

OMEGA_n = 2*pi*Nn/60; %rd/s 
Kc = Cn/OMEGA_n ; %constante de couple cas proportionnel
Kc_pr = Cn/(OMEGA_n^2) ; %constante de couple cas parabol
phi_0 = (Un - R115*In)/OMEGA_n ; %constante de flux

Kfe = Pf/(OMEGA_n)^2; %coefficient de perte fer
f = Pm/(OMEGA_n)^2; %coefficient de frottement
f_pr = Kfe + f; %coefficient de perte fer et frottement ensemble
k = f_pr + Kc;
tau = L/R115; %constante de temps de la mcc

%% choix de couple
disp("Dans ce programme, on peut considerer plusieur choix pour le couple de charge:")
disp("choix 1: Couple constant")
disp("choix 2: Couple proportionnel")
disp("choix 3: Couple parabole")

choix = 0; %pour le choix
cas = 0; %pour la switch 1 en simulink
cas_pr = 0; %pour la switch 2 en simlink
parametre = 1; %parametre de la boucle while qu'on va faire
val_choix_constant = 0;
val_choix_proportionnel = 0;
val_choix_parabole = 0;

while parametre == 1
    choix = input("inserer le choix que vous desirez:")
    if choix == 1
        val_choix_constant = input("inserer le couple de charge qui doit etre inferieur a Cn = 303 N.m:")
        if val_choix_constant<=0 || val_choix_constant>=Cn
            disp("choix incorrect, veuillez resaisir")
        else
            disp("choix correct")
            cas = 1;
            cas_pr = 0;
            parametre = 0;
        end
        
    elseif choix == 2
        val_choix_proportionnel = input("inserer le coefficient k qui doit etre inferieur a Kc = Cn/OMEGA_n = 1.29:")
        if val_choix_proportionnel<=0 || val_choix_proportionnel>=Kc
            disp("choix incorrect, veuillez resaisir")
        else
            disp("choix correct")
            cas = 0;
            cas_pr = 1;
            parametre = 0;
        end
            
    elseif choix == 3
        val_choix_parabole = input("inserer le coefficient k qui doit etre inferieur a Kc_pr = Cn/OMEGA_n^2 = 0.0055:")
        if val_choix_parabole<=0 || val_choix_parabole>=Kc_pr
            disp("choix incorrect, veuillez resaisir")
        else
            disp("choix correct")
            cas = 0;
            cas_pr = 0;
            parametre = 0;
        end
    else
        disp("choix incorrect, veuillez resaisir")
    end
end

%% choix de la resistance de l'induit

R0 = R115;
Tf = 0;
T0 = 0;
alpha_temperature = 4e-3;
choix_resistance = 0;
parametre = 1;

disp("on donne le choix a l'utilisateur de choisir soit une resistance constante soit variable:")
disp("choix 1: constante")
disp("choix 2: variable")

while parametre == 1
    choix_resistance = input("inserer le choix que vous desirez:")
    if choix_resistance == 1
        choix_resistance = 1;
        parametre = 0;
    elseif choix_resistance == 2
        choix_resistance = 0;
        T0 = input("inserer la temperature initial: ")
        Tf = input("inserer la temperature final: ")
        if T0<Tf
            parametre = 0;
        else 
            disp("choix incorrecte, resaisir")
        end
    else
        disp("choix incorrecte, resaisir")
    end
end

%% Regulateur de courant
epsilon_n = 4.69;
Ks = 1/240;
Ka = epsilon_n/(In*Ks);
K_conv = Un/epsilon_n;
H_I_p = tf([J k],[L*J R115*J+k*L (phi_0^2)+k*R115]);
K_o_I = 3/tau;
K_o_I_pr = K_o_I/(K_conv*Ka*Ks);
frequence = 30;
w0 = 2*pi*frequence;
ksi = sqrt(2)/2;
K_gain_courant = K_o_I_pr/2;

%% Regulateur de vitesse
H_OMEGA_I_p = tf(phi_0,[J k]);
K_gain_tachymetre = 90/(2*pi*1500/60); 
K_mise_en_echelle = epsilon_n/(OMEGA_n*K_gain_tachymetre);
tau_vitesse = J/k;
K_o_omega = 3/tau_vitesse;                             
K_o_omega_pr = (K_o_omega*epsilon_n)/(In*K_gain_tachymetre*K_mise_en_echelle);  
K_vitesse = K_o_omega_pr/10;

%% Courbes

sim("TC_MCC_sim.slx")

figure()
plot(t,I_entree,'r'),grid
hold on
plot(t,I_sortie,'b')
legend("I ref","I sortie")
xlabel("temps")
ylabel("courant")

figure()
plot(t,w_ref,'r'),grid
hold on
plot(t,w_sortie,'b')
legend("w ref","w sortie")
xlabel("temps")
ylabel("vitesse")