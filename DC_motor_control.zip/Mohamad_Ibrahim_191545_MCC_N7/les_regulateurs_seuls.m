clear all
close all
clc

%% initialisation
Pn = 78e+3; %W
Un = 400; %V
In = 195; %A
etha = 0.91; %p.u.
Cn = 303; %N.m
Nn = 2240; %tr/min
L = 2.4e-3; %H
R115 = 0.14; %Ohm
J = 0.45; %kg.m^2
Pf_sur_Pm = 2/3;

%% calcule des parametre
Pj = R115*In^2; %W
gamma = Pj/Pn;
alpha = (3/5)*(1-etha-gamma) ;
beta = Pf_sur_Pm*alpha;
Pm = alpha*Pn; %W
Pf = beta*Pn; %W

OMEGA_n = 2*pi*Nn/60; %rd/s 
Kc = Cn/OMEGA_n ; %constante de couple cas proportionnel
Kc_pr = Cn/(OMEGA_n^2) ; %constante de couple cas parabol
phi_0 = (Un - R115*In)/OMEGA_n ; %constante de flux

Kfe = Pf/(OMEGA_n)^2; %coefficient de perte fer
f = Pm/(OMEGA_n)^2; %coefficient de frottement
f_pr = Kfe + f; %coefficient de perte fer et frottement ensemble
k = f_pr + Kc;
tau = L/R115; %constante de temps de la mcc

%% Regulateur de courant
epsilon_n = 4.69;
Ks = 1/240;
Ka = epsilon_n/(In*Ks);
K_conv = Un/epsilon_n;
H_I_p = tf([J k],[L*J R115*J+k*L (phi_0^2)+k*R115]);
K_o_I = 3/tau;
K_o_I_pr = K_o_I/(K_conv*Ka*Ks);
frequence = 30;
w0 = 2*pi*frequence;
ksi = sqrt(2)/2;
K_gain_courant = K_o_I_pr/2;

%% Regulateur de vitesse
H_OMEGA_I_p = tf(phi_0,[J k]);
K_gain_tachymetre = 90/(2*pi*1500/60); 
K_mise_en_echelle = epsilon_n/(OMEGA_n*K_gain_tachymetre);
tau_vitesse = J/k;
K_o_omega = 3/tau_vitesse;                             
K_o_omega_pr = (K_o_omega*epsilon_n)/(In*K_gain_tachymetre*K_mise_en_echelle);

%% simulink des regulateurs seuls
sim("les_regulateurs.slx")
%% courbes de regulateur de courant
figure()
plot(t,I_sortie),grid
hold on
plot(t,I_ref)
xlabel("temps")
ylabel("courant")
legend("sortie","reference")

%% courbes de regulateur de vitesse 
figure()
plot(t,w_sortie),grid
hold on
plot(t,w_ref)
xlabel("temps")
ylabel("vitesse")
legend("sortie","reference")

%% courbes de regulateur complet
figure()

subplot(1,2,1)
plot(t,I_sortie_pr),grid
hold on
plot(t,I_entree)
xlabel("temps")
ylabel("courant")
legend("sortie","reference")

subplot(1,2,2)
plot(t,w_sortie_pr),grid
hold on
plot(t,w_ref_pr)
xlabel("temps")
ylabel("vitesse")
legend("sortie","reference")

