clear all
close all
clc

% Valeurs nominales
Pn = 1100 ;          % (W)
cos_phin = 0.8 ;
Vn = 220 ;          % (V)
Un = Vn*sqrt(3) ;
In = Pn/3/Vn/cos_phin ;         % (A)
fn = 50 ;           % (Hz)
debit = input('Inserer le debit desire entre 4 et 30 m3/h: ');
i = 1;
while i==1
    if debit < 4 || debit > 30
        disp('Choix invalide !!')
        debit = input('Inserer le debit desire entre 4 et 30 m3/h: ');
    elseif debit >= 4 && debit <= 8
        Nref = 750;
        i = 0;
    elseif debit > 8 && debit <= 17
        Nref = 1500;
        i = 0;
    elseif debit > 17 && debit <= 30
        Nref = 2800;
        i = 0;
    end
end
Nn = 2800 ; %tr/mn
Wn = Nn/60*2*pi ;   % (rad/s)
rendn = 0.9 ;

Iref = 0.5*In*sqrt(2) ;

Cn = Pn*rendn/Wn ;

 

% Parametres de la MSAP
Rs = 10.5 ;
Ld = 0.245 ;
Lq = Ld ;
%Lq = 0.229 ;
p = 2 ;

 

Phi_f0 = 0.711 ;
Phi_f = sqrt(3/2)*Phi_f0 ;

J = 0.05 ;
fv = 0.0033 ;
Kond = Un/2 ;
delta = pi/2 ;

% Matrices de Clarke
C32 = [ 1 0 ; -1/2 sqrt(3)/2 ; -1/2 -sqrt(3)/2 ];
C23 = 2/3*[ 1 -1/2 -1/2 ; 0 sqrt(3)/2 -sqrt(3)/2 ];

% Matrices de Concordia
T32 = sqrt(2/3)*C32 ;
T23 = T32' ;

Concordia = sqrt(2/3)*[1 -0.5 -0.5;0 sqrt(3)/2 -sqrt(3/2); 1/sqrt(2) 1/sqrt(2) 1/sqrt(2)];
Concordia_inv = inv(Concordia);

% PI
n = 5 ;
Ti = Ld/Rs ;
Kp = 10*n*Rs/Kond ;
f_Cr = Cn/(Wn^2) ;

% PI Vitesse
m = 1000 ;
TiN = J/fv ;
KpN = m*fv/60*2*pi/(3/2*p*Phi_f0) ;
vitesse = 1 ;

Tsim = 1e-5 ;
Tf = 1 ;

sim('MS')
figure()
plot(t,Courant),grid
ylabel('Courant (A)')
xlabel('Temps (S)')
title('Courant en fonction du temps')

figure()
plot(t,Couple),grid
ylabel('Cem (N.m)')
xlabel('Temps (S)')
legend('Cem','Cem_r_e_f')
title('Couple en fonction du temps')

figure()
plot(t,Vitesse),grid
ylabel('Vitesse (tr/mn)')
xlabel('Temps (S)')
legend('Vitesse_r_e_f','Vitesse')
title('Vitesse en fonction du temps')